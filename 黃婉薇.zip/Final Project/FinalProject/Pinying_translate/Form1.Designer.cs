﻿namespace Pinying_translate
{
    partial class Translate_Form
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置 Managed 資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.shengmu_comboBox = new System.Windows.Forms.ComboBox();
            this.jiemu_comboBox = new System.Windows.Forms.ComboBox();
            this.yunmu_comboBox = new System.Windows.Forms.ComboBox();
            this.shengdiao_comboBox = new System.Windows.Forms.ComboBox();
            this.Translate_button = new System.Windows.Forms.Button();
            this.guozi_textBox = new System.Windows.Forms.TextBox();
            this.ChineseText_comboBox = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.py_textBox = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.Result_textBox = new System.Windows.Forms.TextBox();
            this.Save_button = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 9);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(72, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "國語注音";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(24, 43);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(40, 16);
            this.label2.TabIndex = 1;
            this.label2.Text = "聲母";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(110, 43);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(40, 16);
            this.label3.TabIndex = 2;
            this.label3.Text = "介母";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(203, 43);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(40, 16);
            this.label4.TabIndex = 3;
            this.label4.Text = "韻母";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(288, 43);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(40, 16);
            this.label5.TabIndex = 4;
            this.label5.Text = "聲調";
            // 
            // shengmu_comboBox
            // 
            this.shengmu_comboBox.FormattingEnabled = true;
            this.shengmu_comboBox.Items.AddRange(new object[] {
            "ㄅ",
            "ㄆ",
            "ㄇ",
            "ㄈ",
            "ㄪ",
            "ㄉ",
            "ㄊ",
            "ㄋ",
            "ㄌ",
            "ㄍ",
            "ㄎ",
            "ㄫ",
            "ㄏ",
            "ㄐ",
            "ㄑ",
            "ㄒ",
            "ㄓ",
            "ㄔ",
            "ㄕ",
            "ㄖ",
            "ㄗ",
            "ㄘ",
            "ㄙ"});
            this.shengmu_comboBox.Location = new System.Drawing.Point(16, 74);
            this.shengmu_comboBox.Name = "shengmu_comboBox";
            this.shengmu_comboBox.Size = new System.Drawing.Size(48, 24);
            this.shengmu_comboBox.TabIndex = 5;
            // 
            // jiemu_comboBox
            // 
            this.jiemu_comboBox.FormattingEnabled = true;
            this.jiemu_comboBox.Items.AddRange(new object[] {
            "ㄧ",
            "ㄨ",
            "ㄩ"});
            this.jiemu_comboBox.Location = new System.Drawing.Point(102, 74);
            this.jiemu_comboBox.Name = "jiemu_comboBox";
            this.jiemu_comboBox.Size = new System.Drawing.Size(48, 24);
            this.jiemu_comboBox.TabIndex = 6;
            // 
            // yunmu_comboBox
            // 
            this.yunmu_comboBox.FormattingEnabled = true;
            this.yunmu_comboBox.Items.AddRange(new object[] {
            "ㄚ",
            "ㄛ",
            "ㄝ",
            "ㄟ",
            "ㄞ",
            "ㄠ",
            "ㄡ",
            "ㄢ",
            "ㄤ",
            "ㄣ",
            "ㄥ",
            "ㄦ"});
            this.yunmu_comboBox.Location = new System.Drawing.Point(195, 74);
            this.yunmu_comboBox.Name = "yunmu_comboBox";
            this.yunmu_comboBox.Size = new System.Drawing.Size(48, 24);
            this.yunmu_comboBox.TabIndex = 7;
            // 
            // shengdiao_comboBox
            // 
            this.shengdiao_comboBox.FormattingEnabled = true;
            this.shengdiao_comboBox.Items.AddRange(new object[] {
            "ˉ",
            "ˊ",
            "ˇ",
            "ˋ"});
            this.shengdiao_comboBox.Location = new System.Drawing.Point(280, 74);
            this.shengdiao_comboBox.Name = "shengdiao_comboBox";
            this.shengdiao_comboBox.Size = new System.Drawing.Size(48, 24);
            this.shengdiao_comboBox.TabIndex = 8;
            // 
            // Translate_button
            // 
            this.Translate_button.Location = new System.Drawing.Point(27, 132);
            this.Translate_button.Name = "Translate_button";
            this.Translate_button.Size = new System.Drawing.Size(75, 23);
            this.Translate_button.TabIndex = 9;
            this.Translate_button.Text = "Tranlsate";
            this.Translate_button.UseVisualStyleBackColor = true;
            this.Translate_button.Click += new System.EventHandler(this.Translate_button_Click);
            // 
            // guozi_textBox
            // 
            this.guozi_textBox.Location = new System.Drawing.Point(60, 191);
            this.guozi_textBox.Name = "guozi_textBox";
            this.guozi_textBox.Size = new System.Drawing.Size(100, 27);
            this.guozi_textBox.TabIndex = 10;
            // 
            // ChineseText_comboBox
            // 
            this.ChineseText_comboBox.FormattingEnabled = true;
            this.ChineseText_comboBox.Location = new System.Drawing.Point(184, 191);
            this.ChineseText_comboBox.Name = "ChineseText_comboBox";
            this.ChineseText_comboBox.Size = new System.Drawing.Size(121, 24);
            this.ChineseText_comboBox.TabIndex = 11;
            this.ChineseText_comboBox.SelectedIndexChanged += new System.EventHandler(this.ChineseText_comboBox_SelectedIndexChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(13, 194);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(40, 16);
            this.label6.TabIndex = 12;
            this.label6.Text = "國字";
            // 
            // py_textBox
            // 
            this.py_textBox.Location = new System.Drawing.Point(219, 129);
            this.py_textBox.Name = "py_textBox";
            this.py_textBox.Size = new System.Drawing.Size(100, 27);
            this.py_textBox.TabIndex = 13;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(130, 132);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(72, 16);
            this.label7.TabIndex = 14;
            this.label7.Text = "羅馬拼音";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(13, 250);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(40, 16);
            this.label8.TabIndex = 15;
            this.label8.Text = "造句";
            // 
            // Result_textBox
            // 
            this.Result_textBox.Location = new System.Drawing.Point(93, 247);
            this.Result_textBox.Name = "Result_textBox";
            this.Result_textBox.Size = new System.Drawing.Size(247, 27);
            this.Result_textBox.TabIndex = 16;
            // 
            // Save_button
            // 
            this.Save_button.Location = new System.Drawing.Point(27, 303);
            this.Save_button.Name = "Save_button";
            this.Save_button.Size = new System.Drawing.Size(75, 23);
            this.Save_button.TabIndex = 17;
            this.Save_button.Text = "存檔";
            this.Save_button.UseVisualStyleBackColor = true;
            this.Save_button.Click += new System.EventHandler(this.Save_button_Click);
            // 
            // Translate_Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(352, 349);
            this.Controls.Add(this.Save_button);
            this.Controls.Add(this.Result_textBox);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.py_textBox);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.ChineseText_comboBox);
            this.Controls.Add(this.guozi_textBox);
            this.Controls.Add(this.Translate_button);
            this.Controls.Add(this.shengdiao_comboBox);
            this.Controls.Add(this.yunmu_comboBox);
            this.Controls.Add(this.jiemu_comboBox);
            this.Controls.Add(this.shengmu_comboBox);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Translate_Form";
            this.Text = "外國人學中文";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox shengmu_comboBox;
        private System.Windows.Forms.ComboBox jiemu_comboBox;
        private System.Windows.Forms.ComboBox yunmu_comboBox;
        private System.Windows.Forms.ComboBox shengdiao_comboBox;
        private System.Windows.Forms.Button Translate_button;
        private System.Windows.Forms.TextBox guozi_textBox;
        private System.Windows.Forms.ComboBox ChineseText_comboBox;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox py_textBox;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox Result_textBox;
        private System.Windows.Forms.Button Save_button;
    }
}

