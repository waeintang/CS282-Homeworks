﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace Pinying_translate
{
    public class algorithm
    {
         public Hashtable ht;
            public void InitializeChineseSymbolHash()
            {
                ht.Add("ㄗㄞˋ", "在再載");
                ht.Add("ㄉㄚˋ", "大搭");
                ht.Add("ㄕㄨㄞˋ", "率帥蟀咰繂");
                ht.Add("ㄇㄧㄢˋ", "面麵");
                ht.Add("ㄧㄝˇ", "也野冶埜漜");
                ht.Add("ㄅㄢ-", "班般搬斑頒扳瘢虨斒攽褩");
                ht.Add("ㄅㄧˊ", "鼻");
                ht.Add("ㄞˋ", "愛礙艾曖璦隘噯乂靉僾堨嬡鑀賹濭鴱譪誒薆");
                ht.Add("ㄎㄤˊ", "扛");
                ht.Add("ㄒㄧㄠˇ", "小曉筱篠謏");
                ht.Add("ㄎㄞ-", "開揩痎侅");
                ht.Add("ㄏㄚ-", "哈");
                ht.Add("ㄖㄣˊ", "人任仁壬紝儿芢銋");
                ht.Add("ㄏㄡˇ", "吼");
                ht.Add("ㄌㄤˇ", "朗閬硠峎悢誏烺塱");
                ht.Add("ㄔㄨㄥˊ", "重崇虫蟲种翀蝩隀茧痋");
                ht.Add("ㄔㄨㄥ-", "充衝沖舂忡憧珫茺浺蹖祌");

            }
        }
}
